/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signals.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 22:46:20 by abekri            #+#    #+#             */
/*   Updated: 2024/08/12 22:22:32 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SIGNALS_H
# define SIGNALS_H

void	setup_signal_handlers(void);
void	signal_handler(int sig);
void	sigquit_handler(int signo);
void	start_signal_handlers(void);

#endif
