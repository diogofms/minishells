/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 22:46:11 by abekri            #+#    #+#             */
/*   Updated: 2024/08/13 03:29:26 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include <stdio.h>
# include "../libft/libft.h"
# include <dirent.h>
# include <errno.h>
# include <fcntl.h>
# include <readline/history.h>
# include <readline/readline.h>
# include <signal.h>
# include <stdlib.h>
# include <string.h>
# include <sys/stat.h>
# include <sys/types.h>
# include <sys/wait.h>
# include <unistd.h>
# define MAX_TOKENS 1000
# define WORD 0
# define R_DIR_APPEND 1
# define H_DOC 2
# define ERR 3
# define EOL 4
# define ERR_SYNTX_MSG "Syntax error near token: %c\n"
# define ERR_SYNTX_MSG_RE_H "Syntax error: expected %s before end of line\n"
# define ERROR_EXPORT_MSG \
	"export: usage: export [-nf]\
[name[=value] ...] or export -p"
# define MAX_COMMANDS 10
# define MAX_ENV 50
# define BUFFER_SIZE 1024
# define DEBUG 0
# define TERMINAL_NAME "minishell"
# define MAX_ENV_VARS 1024
# define MAX_ARGS 128
# define MAX_STRING_LEN 5128
# define MAX_LIST_SIZE 100

extern volatile sig_atomic_t	g_signal;

typedef enum e_error_cod
{
	CMD_NOT_EXEC = 126,
	ERR_SYNTX_COD = 258,
	CTRL_C = 130,
	CDM_NOT_EXIST = 127,
}								t_error_cod;

typedef struct s_shell_config
{
	char		*terminal_name;
	char		*pwd;
	char		*home;
	int			out_fd;
	int			in_fd;
	int			*exit_cd;
	char		**envp;
	int			*fds;
}								t_shell_config;

typedef struct s_command_context
{
	char		*input_line;
	char		command_list
	[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE];
	int			command_count;
	int			input_fd;
	int			output_fd;
}								t_command_context;

typedef struct token_etw_s
{
	int			*position;
	int			*isdouble_quote;
	int			*is_single_quote;
}								t_token_etw;

typedef struct redirections_hr_s
{
	int			arg_index;
	int			cmd_index;
}								t_redirections_hr;

typedef struct single_command_rp_s
{
	int			len;
	char		*result;
	char		*temp;
	char		*full_path;
}								t_single_command_rp;

typedef struct single_command_fep_s
{
	int			index;
	char		*path_str;
	char		**path_dirs;
	char		*command_path;
}								t_single_command_fep;

typedef struct single_command_esc_s	
{
	char		*path;
	int			(*fds)[2];
	int			pid;
}								t_single_command_esc;

typedef struct multiple_commands_ecp_s
{
	char		*path;
	char		(*cmds)[MAX_ARGS][BUFFER_SIZE];
	char		**envp;
	int			(*fds)[2];
	int			lst_size;
}								t_multiple_commands_ecp;

typedef struct multiple_commands_emc_s
{
    int         lst_size;
    int         *pids;
    int         (*fds)[2];  
    char        *exec_params[4];
}               t_multiple_commands_emc;

typedef struct echo_ptie_s
{
	int		out_fd;
	char	*home;
	char	*trimmed_home;
	char	*print;
	int		i;
	int		j;
}								t_echo_ptie;

typedef struct echo_ee_s
{
	int	out_fd;
	int	suppress_newline;
	int	i;
	int	*exit_code;
	int	no_flags;
}								t_echo_ee;

typedef struct export_ues_s
{
	char	**new_envp;
	int		new_envp_size;
	char	*var;
	int		i;
	int		j;
}								t_export_ues;

void	init_shell(void);
void	setup_signal_handlers(void);
void	start_iterm(t_shell_config *config);
int		check_parsing(char *input, char **envp,
			int *fds, int *exit_cd);
int	check_syntax(char **tokens, int *values, int count, int *exit_cd);
int		generate_abstract_cmds(char **cmds,
			int token_count, char **envp, int *exit_cd);
int		expansion_success(char **envp, char *input,
			int *fds, int *exit_cd);
int		handle_redirections(char **command_args,
			int command_count, int *file_descriptors,
			int *exit_code);
void	print_2d_array(char **arr, char *msg);
void	adjust_shell_lvl(char **env, int increment);
char	*format_prompt(char *user, char *node, char *path);
char	*format_iterm(char **environment);

int		ft_strcmp(const char *a, const char *b);
// int		pwd(int fd);
// int		malloc_fail(void *str, char *error);
// void	str_cpy(char *a, char **b, int end);
// int		env_cmp(char *current_env, char *new_env);
// char	*strcnc(char *a, char *b);

void	close_file_descriptors(int fds[][2], int size);
int count_commands(char (*command_list)[MAX_ARGS][BUFFER_SIZE]);
void	handle_child_process(char *exec_params[], int fd_info[], int lst_size);
size_t	ft_strlen(const char *s);
void	print_error_message(char *message1,
			char *message2, int c, int *exit_cd);
void	print_error_message_exit(char *error_message, int error_code,
			int *exit_code);
void	fatal_error(char *message);
void	exec_command(char *exec_path,
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			char **env_vars, int *exit_code);
void	wait_for_child(int *exit_code, int child_pid, char *resource_path);
void	setup_fds(int file_descriptors[][2], int input_fd, int output_fd,
			int index);
int		is_builtin(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE]);
void	run_builtin(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			char **env_vars, int *exit_code, int out_fd);
char	*resolve_path(char commands[MAX_LIST_SIZE][MAX_ARGS][BUFFER_SIZE],
			char *s, int *exit_cd);
char	*get_env_var(char **env_array, const char *key);
char	*find_exec_path(char commands[MAX_LIST_SIZE][MAX_ARGS][BUFFER_SIZE],
			char *env_array[], char *command_name, int *exit_cd);
void	print_commands(char **cmds, int cmd_count, char *str_msg);
void	print_array(char **array, char *msg);
void	free_str(char *str);
int		check_valid_env_char(char *str);
int		handle_exit_status(int exit_code, int *i, char **expanded_str);
void	handle_double_quotes(char **args,
			int *i, char **expanded_str, char **envp);
int		handle_env_variable(char **args,
			int *i, char **expanded_str, char **envp);
char	*ft_strncat(char *s1, char *s2, int n);
char	**combine_arrays(char **array_1, char **array_2, int start,
			int *exp_flag);
char	*successful_expansion(char **envp, char *arg, char **expanded_str,
			int *exp_flag);
void	remove_elements(char **args_array, int *current_position,
			int num_elements_to_remove);
int		verify_fd_perm(char *file_path);
int		verify_fd_type(char *file_path);
int		handle_output_append(char **command_args,
			int *arg_index, int *output_fd);
int		extract_token_word(char *line, int *pos_info, int *token_info,
			char **token_vals);
void	skip_spaces(char *line, int *position);
int		build_token(int type, char *val, int *token_info, char **token_vals);
int		ft_is_space(char c);
void	setup_command_context(t_command_context *context);
void	finalize(char *pwd, char *home);
int		read_input(t_shell_config *config, t_command_context *context);
void	process_input(t_command_context *context, t_shell_config *config);
int		check_parsing(char *input, char **envp, int *fds, int *exit_cd);
void	handle_error(char *input, int *exit_cd);
void	initialize_command_list(
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE]);
void	change_to_rel_path(
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			char **env_vars, int *exit_cd);
void	change_to_abs_path(
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			char **env_vars, int *exit_cd);
void	change_to_home_dir(char **env_vars,
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			int *exit_cd);
int		get_prev_dir_len(const char *cwd);
char	*remove_tilda_from_path(const char *s);
void	update_old_env_variable(char **envp, const char *owd);
char	*build_home_directory(char **envp, char *future_wd);
void	ft_cd(
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			char **env_vars, int *exit_cd);
int		check_in_envp(char **envp, const char *var);
void	modify_env_variable(char **envp, const char *var, const char *value);
char	*retrieve_env_variable(char **envp, const char *var);
void	change_to_tilda_path(char **env_vars,
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			int *exit_cd);
void	change_to_prev_dir(char **envp, int *exit_cd);
int		check_echo_flag(char *s);
void	handle_echo_newline(int out_fd, int *exit_code, int flag);
void	print_echo_arguments(char args[MAX_ARGS][BUFFER_SIZE], char **env_vars,
			int params[], int index);
void	ft_env(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			char **env_vars, int *exit_code, int out_fd);
void ft_exit(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE], int *fds, int *exit_cd);

void	ft_export(char args[MAX_ARGS][BUFFER_SIZE], char **envp, int *exit_cd,
			int out_fd);
int		ft_find_in_envp(char **envp, char *var);
void	ft_echo(
			char args[MAX_ARGS][BUFFER_SIZE], char **env_vars, int params[]);
int		handle_export_errors(char args[MAX_ARGS][BUFFER_SIZE], int i);
char	*extract_env_var_name(char *env_line);
char	**ft_sort_env_vars(char **envp, char **sorted_vars);
int		ft_check_export_string(char *s);
int		ft_calculate_export_exit_status(char args[MAX_ARGS][BUFFER_SIZE]);
int		ft_has_value_after_equal(char *arg);
void	ft_replace_env_var(char **envp, char *replace, int idx);
void	ft_append_to_env_var(char **envp, int i, char *to_add, char *var);
void	ft_add_plus_minus(char **envp, int i, char *to_add);
void	ft_append_to_env_var_ex(char **envp, int i, char *to_add, char *var);
void	ft_pwd(char args[MAX_ARGS][BUFFER_SIZE], int *exit_code, int out_fd);
void	ft_unset(char args[MAX_ARGS][BUFFER_SIZE], char **envp, int *exit_code);

void	print_error_message_extra(char *message1, char *message2, int c,
		int exit_code_array[]);

int		find_env_var_index(char **envp, char *var, int params[]);
int		handle_unset_errors(char args[MAX_ARGS][BUFFER_SIZE], int *exit_code);
void	free_token_list(char **token_vals, int token_count);
void	execution_command(
			char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			int cmd_count, int *fds, int *exit_cd);
void	exec_multiple_cmd(
			char command_list[MAX_LIST_SIZE][MAX_ARGS][BUFFER_SIZE],
			char *envp[], int *fd_info, int *exit_cd);
int (*create_fds(int num_pairs, int use_pipes))[2];
void cleanup_fds(int (*fd)[2], int length);
void	ft_reset_io(int **fds, int ind);
void	free_2d_array(char **array);
int		get_next_token(char *line, int *pos_info, int *token_info,
			char **token_vals);
void	exec_single_cmd(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
			char **envp, int *fd_infile_outfile, int *exit_cd);
int		check_alpha_flag(char *s);
int		validate_string_content(char *s);
char	*get_old_shell_level(char **env);
char	*get_new_level_num(char *old_lvl_num, int increment);
void	update_env_with_new_level(char **env, char *new_lvl_str);
void	ft_update_shell_level(char **env, int increment);
void	free_shell(char **env, char *s);
char	*bring_env(char **env, char const *n);
char	*extract_value(char *s);
void	params_start(char **args, char *s);
void	get_args_empty(char **args);
void	perform_child_process_and_store_output(char **args, char *output);
void	add_missing_vars(char *mini_env[], int *i);
void	setup_env(char *orig_env[], char *mini_env[], int count);
void	free_mini_env(char **mini_env);
void	init_env(char **env, char **mini_env, int count);
int		count_env_vars(char **env);
char	*get_cwd(void);
char	*get_home(void);
void	start_info_ms(char **env, char **term_name, char **mini_env,
		int *exit_code);
int		is_var_set(char **env, char *var);
int		find_var_index(char **env, char *var);
int		has_prefix(char *env[], char *s);
void	copy_env_var(char *orig_env[], char *mini_env[], int *i);
void	update_new_path(char **envp, const char *pwd);
int		check_numeric_flag(char *s);
int		execute_heredoc(int fd, char *delimiter, char **envp, int *exp_flag);
int		handle_input_heredoc(char **command_args, int *arg_index, int *input_fd,
			int *exit_code);
int		needs_expansion(char **envp, char **arg, int *exp_flag);
void	print_error(char *s, int *exit_cd);
void    signal_handler_end(void);
void    signal_handler_init(void);
void null_check_free_str(char *s);
int ft_cd_minus_envp(char **envp, const char *var);
char *ft_getenv(char **envp, const char *name);
char *ft_trim_path(char *path);
void ft_cd_update_old_env(char **envp, const char *cwd);
void ft_cd_new_pwd(char **envp, const char *pwd);
int	find_minus_in_envp(char **envp, const char *var);
void	remove_element(char **cmds, int *j);
int	perform_lexical_analysis(char *readline, char ***cmds, int *fds,
		int *exit_cd);
#endif
