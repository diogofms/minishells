/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   single_commands_part4.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:44:31 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 01:15:31 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

char	*check_access(char *command_name, char commands[MAX_ARGS][BUFFER_SIZE],
		int *exit_cd)
{
	char	*result;

	result = ft_strdup(command_name);
	free_str(command_name);
	if (access(result, F_OK | X_OK) == 0)
		return (result);
	print_error_message_exit(commands[0], 2, exit_cd);
	return (free(result), NULL);
}

char	*strip_path(char *full_path)
{
	char	*stripped_path;
	int		index;
	int		temp_index;

	index = 0;
	while (full_path[index] != '\0' && full_path[index] != '=')
		index++;
	stripped_path = malloc((ft_strlen(full_path) - index) + 1);
	if (!stripped_path)
		perror("find_path.c line 46");
	temp_index = 0;
	index++;
	while (full_path[index] != '\0')
		stripped_path[temp_index++] = full_path[index++];
	stripped_path[temp_index] = '\0';
	free(full_path);
	return (stripped_path);
}

char	*iterate_paths(t_single_command_fep *vars, char *command_name)
{
	vars->index = -1;
	while (vars->path_dirs[++vars->index] != NULL)
	{
		vars->path_str = ft_strjoin(vars->path_dirs[vars->index],
				vars->command_path);
		if (access(vars->path_str, F_OK | X_OK) == 0)
		{
			free(vars->command_path);
			free_2d_array(vars->path_dirs);
			return (vars->path_str);
		}
		free(vars->path_str);
	}
	free(vars->command_path);
	free_2d_array(vars->path_dirs);
	return (command_name);
}

char	*find_exec_path(char commands[MAX_LIST_SIZE][MAX_ARGS][BUFFER_SIZE],
		char *env_array[], char *command_name, int *exit_cd)
{
	t_single_command_fep	vars;

	if (command_name[0] == '/')
		return (check_access(command_name, commands[0], exit_cd));
	if (command_name[0] == '.' && command_name[1] == '/'
		&& command_name[2] != '\0')
		return (resolve_path(commands, command_name, exit_cd));
	vars.path_str = get_env_var(env_array, "PATH");
	if (!vars.path_str)
	{
		print_error_message_exit("PATH environment variable not found", 2,
			exit_cd);
		free(command_name);
		return (NULL);
	}
	vars.path_dirs = ft_split(vars.path_str, ':');
	free(vars.path_str);
	vars.path_dirs[0] = strip_path(vars.path_dirs[0]);
	vars.command_path = ft_strjoin("/", command_name);
	return (iterate_paths(&vars, command_name));
}

void	cleanup_resources(char *data[], int array_count, int string_count)
{
	char	**environment_vars;
	char	**command_list;
	int		index;

	environment_vars = (char **)data[0];
	command_list = (char **)data[1];
	if (environment_vars)
		free_2d_array(environment_vars);
	if (command_list)
		free_2d_array(command_list);
	index = array_count;
	while (index < array_count + string_count)
	{
		if (data[index])
			free(data[index]);
		index++;
	}
}
