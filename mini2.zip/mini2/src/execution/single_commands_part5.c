/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   single_commands_part5.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:46:02 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 22:23:22 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"
#include "../../include/signals.h"

void	exec_single_cmd_execution(t_single_command_esc *vars,
		char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE], char **envp,
		int *exit_cd)
{
	if (vars->pid == -1)
		fatal_error("single exec fork() fail");
	else if (vars->pid == 0)
		exec_command(vars->path, command_list, envp, exit_cd);
	else
		wait_for_child(exit_cd, vars->pid, vars->path);
	setup_signal_handlers();
}

void	exec_single_cmd(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
char **envp, int *fd_infile_outfile, int *exit_cd)
{
	t_single_command_esc	vars;

	g_signal = 1;
	start_signal_handlers();
	vars.fds = create_fds(2, 1);
	vars.fds[1][0] = fd_infile_outfile[0];
	vars.fds[1][1] = fd_infile_outfile[1];
	setup_fds(vars.fds, fd_infile_outfile[0], fd_infile_outfile[1], 0);
	if (is_builtin(command_list))
	{
		run_builtin(command_list, envp, exit_cd, fd_infile_outfile[1]);
		ft_reset_io((int **)vars.fds, 0); 
		return ;
	}
	vars.path = ft_strdup(command_list[0][0]);
	vars.path = find_exec_path(command_list, envp, vars.path, exit_cd);
	if (!vars.path)
		return ;
	vars.pid = fork();
	exec_single_cmd_execution(&vars, command_list, envp, exit_cd);
}
