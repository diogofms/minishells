/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   multiple_command_part2.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:47:42 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 22:22:47 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"
#include "../../include/signals.h"

void    close_file_descriptors(int fds[][2], int size)
{
    int    i;

    i = -1;
    while (++i < size)
    {
        close(fds[i][0]);
        close(fds[i][1]);	
    }
}

void	wait_for_child_processes(int *pids, int (*fds)[2],
	int lst_size, int *exit_cd)
{
	int	i;
	int	status;

	close_file_descriptors(fds, lst_size);
	i = 0;
	while (i < lst_size)
	{
		waitpid(pids[i], &status, 0);
		if (WIFEXITED(status))
			*exit_cd = WEXITSTATUS(status);
		if (WIFSIGNALED(status))
			*exit_cd = WTERMSIG(status) + 128;
		i++;
	}
	g_signal = 0;
	setup_signal_handlers();
}

void exec_multiple_cmd(
    char command_list[MAX_LIST_SIZE][MAX_ARGS][BUFFER_SIZE],
    char *envp[], int *fd_info, int *exit_cd)
{
    t_multiple_commands_emc    vars;
    int                        i;

    vars.exec_params[1] = (char *)command_list;
    vars.exec_params[2] = (char *)envp;
    vars.exec_params[3] = (char *)exit_cd;
    start_signal_handlers();
    vars.lst_size = count_commands(command_list);
    vars.fds = create_fds(vars.lst_size, 1);
    vars.pids = malloc(vars.lst_size * sizeof(int));
    if (!vars.pids)
        fatal_error("Malloc pids");
    i = 0;
    while (i < vars.lst_size)
    {
        vars.pids[i] = fork();
        if (vars.pids[i] == -1)
            fatal_error("single exec fork() fail");
        if (vars.pids[i] == 0)
            handle_child_process(vars.exec_params, fd_info, vars.lst_size);
        i++;
    }
    wait_for_child_processes(vars.pids, vars.fds, vars.lst_size, exit_cd);
    free(vars.pids);
    cleanup_fds(vars.fds, vars.lst_size);
}
