/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   multiple_command.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/06 06:17:42 by abekri            #+#    #+#             */
/*   Updated: 2024/08/12 00:06:15 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int count_commands(char (*command_list)[MAX_ARGS][BUFFER_SIZE])
{
    int i;

    i = 0;
    while (i < MAX_LIST_SIZE && command_list[i][0][0] != '\0')
    {
        i++;
    }
    return (i);
}

void	configure_io_redirection(int fds[][2], int fd_info[], int size)
{
	int	fd_infile;
	int	fd_outfile;

	fd_infile = fd_info[2];
	fd_outfile = fd_info[3];
	close_file_descriptors(fds, size);
	if (fd_infile != STDIN_FILENO)
	{
		if (dup2(fd_infile, STDIN_FILENO) == -1)
			fatal_error("Dup 5");
		close(fd_infile);
	}
	if (fd_outfile != STDOUT_FILENO)
	{
		if (dup2(fd_outfile, STDOUT_FILENO) == -1)
			fatal_error("Dup 6");
		close(fd_outfile);
	}
}

void	setup_file_descriptors(int fds[][2], int fd_info[], int size)
{
	int	i;
	int	cmd_next;

	i = fd_info[0];
	cmd_next = fd_info[1];
	if (i == 0)
	{
		if (dup2(fds[i][1], STDOUT_FILENO) == -1)
			fatal_error("Dup 1");
	}
	else if (cmd_next == 0)
	{
		if (dup2(fds[i - 1][0], STDIN_FILENO) == -1)
			fatal_error("Dup 2");
	}
	else
	{
		if (dup2(fds[i - 1][0], STDIN_FILENO) == -1)
			fatal_error("Dup 3");
		if (dup2(fds[i][1], STDOUT_FILENO) == -1)
			fatal_error("Dup 4");
	}
	configure_io_redirection(fds, fd_info, size);
}

void	execute_child_process(char *exec_params[], int fd_info[], int *exit_cd)
{
	t_multiple_commands_ecp	vars;
	int						i;

	vars.path = exec_params[0];
	vars.cmds = (char (*)[MAX_ARGS][BUFFER_SIZE])exec_params[1];
	vars.envp = (char **)exec_params[2];
	vars.fds = (int (*)[2])exec_params[3];
	i = fd_info[0];
	vars.lst_size = fd_info[1];
	if (vars.cmds[i + 1] != NULL)
		fd_info[1] = 1;
	else
		fd_info[1] = 0;
	setup_file_descriptors(vars.fds, fd_info, vars.lst_size);
	if (execve(vars.path, (char *const *)vars.cmds[i], vars.envp) == -1)
	{
		print_error_message_exit(vars.cmds[i][0], 1, exit_cd);
		free(vars.path);
		*exit_cd = 127;
		exit(*exit_cd);
	}
	free(vars.path);
	exit(EXIT_SUCCESS);
}

void	handle_child_process(char *exec_params[], int fd_info[], int lst_size)
{
	char	*path;
	char	(*cmds)[MAX_ARGS][BUFFER_SIZE]; 
	char	**envp;
	int		(*fds)[2]; 

	(void)lst_size; 
	path = NULL;
	cmds = (char (*)[MAX_ARGS][BUFFER_SIZE])exec_params[1]; 
	envp = (char **)exec_params[2];
	fds = (int (*)[2])exec_params[3]; 
	if (!is_builtin(cmds))
	{
		path = find_exec_path((char (*)[MAX_ARGS][BUFFER_SIZE])cmds, envp, cmds[0][0], &fd_info[4]); 
		if (!path)
			return ;
	}
	exec_params[0] = path;
	execute_child_process(exec_params, fd_info, &fd_info[4]); 
}