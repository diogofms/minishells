/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   single_commands_part2.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amohame2 <amohame2@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:42:50 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 22:25:40 by amohame2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	exec_command(char *exec_path,
		char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE], char **env_vars,
		int *exit_code)
{
	char	*args[MAX_ARGS + 1];
	int		i;

	i = 0;
	while (i < MAX_ARGS && command_list[0][i][0] != '\0')
	{
		args[i] = command_list[0][i];
		i++;
	}
	args[i] = NULL;

	if (execve(exec_path, args, env_vars) == -1)
	{
		print_error_message_exit(command_list[0][0], 1, exit_code);
		free_str(exec_path);
		*exit_code = 127;
		exit(*exit_code);
	}
}

void	wait_for_child(int *exit_code, int child_pid, char *resource_path)
{
	int	process_status;

	waitpid(child_pid, &process_status, 0);
	if (WIFEXITED(process_status))
		*exit_code = WEXITSTATUS(process_status);
	if (WIFSIGNALED(process_status))
		*exit_code = WTERMSIG(process_status) + 128;
	free_str(resource_path);
	g_signal = 0;
}

void	setup_fds(int file_descriptors[][2], int input_fd, int output_fd,
		int index)
{
	if (input_fd != STDIN_FILENO)
	{
		if (dup2(file_descriptors[index][0], STDIN_FILENO) == -1)
			fatal_error("Dup 7");
		close(input_fd);
	}
	if (output_fd != STDOUT_FILENO)
	{
		if (dup2(file_descriptors[index][1], STDOUT_FILENO) == -1)
			fatal_error("Dup 8");
		close(output_fd);
	}
}

int	is_builtin(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE])
{
	if (ft_strncmp(command_list[0][0], "pwd",
		ft_strlen(command_list[0][0])) == 0)
		return (1);
	else if (ft_strncmp(command_list[0][0], "cd",
		ft_strlen(command_list[0][0])) == 0)
		return (1);
	else if (ft_strncmp(command_list[0][0], "echo",
		ft_strlen(command_list[0][0])) == 0)
		return (1);
	else if (ft_strncmp(command_list[0][0], "export",
		ft_strlen(command_list[0][0])) == 0)
		return (1);
	else if (ft_strncmp(command_list[0][0], "env",
		ft_strlen(command_list[0][0])) == 0)
		return (1);
	else if (ft_strncmp(command_list[0][0], "unset",
		ft_strlen(command_list[0][0])) == 0)
		return (1);
	return (0);
}
