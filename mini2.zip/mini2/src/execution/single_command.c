/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   single_command.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/06 02:26:34 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 00:06:10 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	print_error_message(char *message1, char *message2, int c, int *exit_cd)
{
	ft_putstr_fd("minishell: ", 2);
	ft_putstr_fd(message1, 2);
	if (message2 != NULL)
		ft_putstr_fd(message2, 2);
	if (c == 1)
	{
		ft_putendl_fd(": numeric argument required", 2);
		*exit_cd = 255;
		exit(255);
	}
	else if (c == 2)
	{
		ft_putendl_fd(": too many arguments", 2);
		*exit_cd = 1;
	}
	else if (c == 3)
	{
		ft_putendl_fd(": OLDPWD not set", 2);
		*exit_cd = 1;
	}
	else if (c == 4)
	{
		ft_putendl_fd(": HOME not set", 2);
		*exit_cd = 1;
	}
}

void	print_error_message_exit(char *message, int c, int *exit_cd)
{
	ft_putstr_fd("minishell: ", 2);
	ft_putstr_fd(message, 2);
	if (c == 1)
	{
		ft_putendl_fd(": command not found", 2);
		*exit_cd = 127;
	}
	else if (c == 2)
	{
		ft_putendl_fd(": No such file or directory", 2);
		*exit_cd = 1;
	}
	else if (c == 3)
	{
		ft_putendl_fd(": not enough arguments", 2);
		*exit_cd = 1;
	}
	else if (c == 4)
	{
		ft_putendl_fd(": HOME not set", 2);
		*exit_cd = 1;
	}
}

void	fatal_error(char *message)
{
	perror(message);
	exit(1);
}

int (*create_fds(int num_pairs, int use_pipes))[2]
{
    int index;
    int (*fd_pairs)[2];

    fd_pairs = malloc(num_pairs * sizeof(*fd_pairs));
    if (!fd_pairs)
        fatal_error("Malloc fd_pairs");
    index = 0;
    while (index < num_pairs)
    {
        if (use_pipes && pipe(fd_pairs[index]) < 0)
            fatal_error("Pipe");
        index++;
    }
    return fd_pairs;
}
