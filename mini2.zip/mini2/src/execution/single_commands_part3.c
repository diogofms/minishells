/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   single_commands_part3.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:43:52 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 01:16:13 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	run_builtin(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		char **env_vars, int *exit_code, int out_fd)
{
	char	*cmd;
	int		params[3];

	params[0] = out_fd;
	params[1] = 1;
	params[2] = *exit_code;
	cmd = command_list[0][0];
	if (ft_strncmp(cmd, "pwd", ft_strlen(cmd)) == 0)
		ft_pwd(command_list[0], exit_code, out_fd);
	else if (ft_strncmp(cmd, "cd", ft_strlen(cmd)) == 0)
		ft_cd(command_list, env_vars, exit_code);
	else if (ft_strncmp(cmd, "echo", ft_strlen(cmd)) == 0)
	{
		ft_echo(command_list[0], env_vars, params);
		*exit_code = params[2];
	}
	else if (ft_strncmp(cmd, "export", ft_strlen(cmd)) == 0)
		ft_export(command_list[0], env_vars, exit_code, out_fd);
	else if (ft_strncmp(cmd, "env", ft_strlen(cmd)) == 0)
		ft_env(command_list, env_vars, exit_code, out_fd);
	else if (ft_strncmp(cmd, "unset", ft_strlen(cmd)) == 0)
		ft_unset(command_list[0], env_vars, exit_code);
}

void cleanup_fds(int (*fd)[2], int length)
{
    int i;

    i = 0;
    while (i < length)
    {
        free(fd[i]);
        i++;
    }
    free(fd);
}

void ft_reset_io(int **fds, int ind)
{
    if (dup2(fds[ind][0], STDIN_FILENO) == -1)
        fatal_error("Dup2 failed for stdin");
    if (dup2(fds[ind][1], STDOUT_FILENO) == -1)
        fatal_error("Dup2 failed for stdout");
    close(fds[ind][0]);
    close(fds[ind][1]);
    cleanup_fds((int (*)[2])fds, 2);
}

char	*resolve_path(char commands[MAX_LIST_SIZE][MAX_ARGS][BUFFER_SIZE],
		char *s, int *exit_cd)
{
	char	*result;
	char	*temp;
	char	*temp_input_path;
	int		i;

	temp = getcwd(NULL, 0);
	temp_input_path = malloc(ft_strlen(s));
	i = 0;
	while (s[++i] != '\0')
		temp_input_path[i - 1] = s[i];
	temp_input_path[i - 1] = '\0';
	result = ft_strjoin(temp, temp_input_path);
	free(temp);
	free(temp_input_path);
	if (access(result, F_OK | X_OK) == 0)
		return (free_str(s), result);
	print_error_message_exit(commands[0][0], 2, exit_cd);
	free_str(s);
	return (free(result), NULL);
}

char	*get_env_var(char **env_array, const char *key)
{
	size_t	key_len;
	char	*value;
	int		ind;

	key_len = ft_strlen(key);
	ind = 0;
	while (env_array[ind] != NULL)
	{
		if (ft_strncmp(env_array[ind], key, key_len) == 0
			&& env_array[ind][key_len] == '=')
		{
			value = ft_strdup(env_array[ind]);
			return (value);
		}
		ind++;
	}
	return (NULL);
}
