/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execution_command.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/05 21:14:16 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 02:29:54 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	free_commands(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		int cmd_count)
{
	int	i;
	int	j;

	i = 0;
	while (i < cmd_count)
	{
		j = 0;
		while (j < MAX_ARGS)
		{
			if (command_list[i][j][0] != '\0')
			{
				free(command_list[i][j]);
			}
			j++;
		}
		i++;
	}
}

void	execution_command(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		int cmd_count, int *fds, int *exit_cd)
{
	char	*first_cmd;
	char	**envp;
	char	**token_list;

	envp = NULL;
	token_list = NULL;
	if (cmd_count > 0)
	{
		first_cmd = command_list[0][0];
		if (ft_strncmp(first_cmd, "&&", 3) == 0)
		{
			print_error(first_cmd, exit_cd);
		}
		else if (ft_strncmp(first_cmd, "exit", 5) == 0)
		{
			ft_exit(command_list, fds, exit_cd);
		}
		else if (cmd_count == 1)
		{
			token_list = (char **)command_list[0];
			exec_single_cmd(command_list, envp, fds, exit_cd);
		}
		else if (cmd_count > 1)
		{
			token_list = (char **)command_list[0];
			exec_multiple_cmd(command_list, envp, fds, exit_cd);
		}
		else
		{
			print_error_message_exit(first_cmd, 1, exit_cd);
		}
		if (token_list != NULL)
		{
			free_token_list(token_list, cmd_count);
		}
		free_commands(command_list, cmd_count);
	}
}
