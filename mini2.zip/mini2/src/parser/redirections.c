/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirections.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 05:37:35 by abekri            #+#    #+#             */
/*   Updated: 2024/08/12 02:20:47 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	remove_elements(char **args_array, int *current_position,
		int num_elements_to_remove)
{
	int	total_args;
	int	start_index;
	int	end_index;

	total_args = -1;
	start_index = *current_position - 1;
	end_index = *current_position;
	while (args_array[++total_args])
		;
	while (end_index < *current_position + num_elements_to_remove)
		free_str(args_array[end_index++]);
	while (++start_index < total_args - num_elements_to_remove)
		args_array[start_index] = args_array[start_index
			+ num_elements_to_remove];
	args_array[total_args - num_elements_to_remove] = NULL;
	(*current_position)--;
}

int	verify_fd_perm(char *file_path)
{
	if (access(file_path, F_OK) == -1)
	{
		ft_putstr_fd(TERMINAL_NAME, STDERR_FILENO);
		ft_putstr_fd(": ", STDERR_FILENO);
		ft_putstr_fd(file_path, STDERR_FILENO);
		ft_putstr_fd(": No such file or directory\n", STDERR_FILENO);
		return (0);
	}
	return (1);
}

int	verify_fd_type(char *file_path)
{
	int		file_descriptor;
	char	buffer[1024];
	ssize_t	bytes_read;

	file_descriptor = open(file_path, O_RDONLY);
	if (file_descriptor == -1)
		return (0);
	bytes_read = read(file_descriptor, buffer, sizeof(buffer));
	close(file_descriptor);
	if (bytes_read == -1)
	{
		ft_putstr_fd(TERMINAL_NAME, STDERR_FILENO);
		ft_putstr_fd(": ", STDERR_FILENO);
		ft_putstr_fd(file_path, STDERR_FILENO);
		ft_putstr_fd(": is a directory\n", STDERR_FILENO);
		return (0);
	}
	return (1);
}

int	handle_output_append(char **command_args, int *arg_index, int *output_fd)
{
	if (*output_fd != STDOUT_FILENO)
		close(*output_fd);
	if (ft_strncmp(command_args[*arg_index], ">", 2) == 0)
		*output_fd = open(command_args[*arg_index + 1],
				O_CREAT | O_RDWR | O_TRUNC, 0644);
	if (ft_strncmp(command_args[*arg_index], ">>", 2) == 0)
		*output_fd = open(command_args[*arg_index + 1],
				O_CREAT | O_RDWR | O_APPEND, 0644);
	if (*output_fd == -1)
		return (ft_putstr_fd(TERMINAL_NAME, STDERR_FILENO), 0);
	return (remove_elements(command_args, arg_index, 2), 1);
}
