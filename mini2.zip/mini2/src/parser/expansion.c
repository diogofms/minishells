/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expansion.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 02:00:04 by abekri            #+#    #+#             */
/*   Updated: 2024/08/10 01:04:02 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	ft_strcmp(const char *s1, const char *s2)
{
	while (*s1 && (*s1 == *s2))
	{
		s1++;
		s2++;
	}
	return (*(const unsigned char *)s1 - *(const unsigned char *)s2);
}

int	expand_variable(char **args, int *i, char **expanded_str, char **envp)
{
	if (args[*i] && (ft_strcmp(args[*i], "?") == 0 || ft_strcmp(args[*i],
				"$") == 0))
	{
		if (ft_strcmp(args[*i], "?") == 0)
		{
			if (!handle_exit_status(0, i, expanded_str))
				return (0);
		}
		else if (ft_strcmp(args[*i], "$") == 0)
		{
			if (!handle_exit_status(95394, i, expanded_str))
				return (0);
		}
	}
	else
	{
		if (!handle_env_variable(args, i, expanded_str, envp))
			return (0);
	}
	return (1);
}

char	*handle_single_quotes(char *arg, int *i, char **expanded_str)
{
	int	start;
	int	end;

	start = ++(*i);
	while (arg[*i] && ft_strncmp(arg + *i, "'", 1) != 0)
		(*i)++;
	end = *i;
	(*i)++;
	*expanded_str = ft_strncat(*expanded_str, arg + start, end - start);
	return (*expanded_str);
}

void	handle_double_quotes(char **args,
	int *i, char **expanded_str, char **envp)
{
	while (args && args[*i] && ft_strcmp(args[*i], "\"") != 0)
	{
		if (args[*i] && ft_strcmp(args[*i], "$") == 0 && ft_strcmp(args[*i + 1],
				" ") != 0 && ft_strcmp(args[*i + 1], "\"") != 0)
		{
			expand_variable(args, i, expanded_str, envp);
		}
		else
		{
			*expanded_str = ft_strncat(*expanded_str,
					args[*i], ft_strlen(args[*i]));
		}
		(*i)++;
	}
}

char	*successful_expansion(char **envp, char *arg, char **expanded_str,
		int *exp_flag)
{
	int		i;
	char	*args[2];

	args[0] = arg;
	args[1] = NULL;
	i = 0;
	while (arg[i])
	{
		if (ft_strncmp(arg + i, "'", 1) == 0)
			handle_single_quotes(arg, &i, expanded_str);
		else if (ft_strncmp(arg + i, "\"", 1) == 0)
			handle_double_quotes(args, &i, expanded_str, envp);
		else if (ft_strncmp(arg + i, "$", 1) == 0 && arg[i + 1] != '\0')
		{
			if (expand_variable(args, &i, expanded_str, envp))
				*exp_flag = 1;
		}
		else
		{
			*expanded_str = ft_strncat(*expanded_str, arg + i, 1);
			i++;
		}
	}
	return (*expanded_str);
}
