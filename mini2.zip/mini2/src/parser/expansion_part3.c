/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expansion_part3.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:07:50 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 02:19:32 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

char	*extract_env_value(char **var_env_names, char *var_name)
{
	int	var_len;
	int	index;

	var_len = ft_strlen(var_name);
	index = 0;
	while (var_env_names && var_env_names[index])
	{
		if (ft_strncmp(var_env_names[index], var_name, var_len) == 0
			&& var_env_names[index][var_len] == '=')
		{
			return (ft_substr(var_env_names[index] + var_len + 1, 0,
					ft_strlen(var_env_names[index] + var_len + 1)));
		}
		index++;
	}
	return (NULL);
}

char	*ft_strncat(char *s1, char *s2, int n)
{
	char	*str;
	int		i;
	int		j;

	i = 0;
	j = 0;
	if (!s1 && !s2)
		return (NULL);
	str = (char *)malloc((ft_strlen(s1) + n + 1) * sizeof(char));
	if (!str)
		return (NULL);
	while (s1 && s1[i] != '\0')
	{
		str[i] = s1[i];
		i++;
	}
	while (j < n && s2 && s2[j] != '\0')
		str[i++] = s2[j++];
	str[i] = '\0';
	free_str(s1);
	return (str);
}

int	handle_env_variable(char **args, int *i, char **expanded_str, char **envp)
{
	char	*env_var;
	char	*var_env_value;
	int		start;
	int		end;
	char	*new_expanded_str;

	start = *i;
	while (args[*i] && check_valid_env_char(args[*i]))
		(*i)++;
	end = *i;
	env_var = ft_substr(args[start], 0, end - start);
	if (!env_var)
		return (0);
	var_env_value = extract_env_value(envp, env_var);
	free(env_var);
	if (!var_env_value)
		return (0);
	new_expanded_str = ft_strncat(*expanded_str, var_env_value,
			ft_strlen(var_env_value));
	free(var_env_value);
	if (!new_expanded_str)
		return (0);
	*expanded_str = new_expanded_str;
	(*i)--;
	return (1);
}
