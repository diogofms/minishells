/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_syntax.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/25 02:32:54 by abekri            #+#    #+#             */
/*   Updated: 2024/08/13 03:28:01 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	check_pipe_err(char **tokens, int count, int *exit_cd)
{
	int	i;

	i = 0;
	while (i < count)
	{
		if (*tokens[i] == '|')
		{
			if (i == 0 || i == count - 1 || 
				(i > 0 && *tokens[i - 1] == '|') ||
				(i < count - 1 && *tokens[i + 1] == '|') ||
				(i < count - 1 && *tokens[i + 1] == EOL))
			{
				dup2(STDERR_FILENO, STDOUT_FILENO);
				printf(ERR_SYNTX_MSG, '|');
				dup2(STDOUT_FILENO, STDERR_FILENO);
				*exit_cd = 2;
				return (0);
			}
		}
		i++;
	}
	return (1);
}

int	check_redir_err(char **tokens, int count, int *values, int *exit_cd)
{
	int	i;

	(void)values;
	i = 0;
	while (i < count)
	{
		if (*tokens[i] == '<' || *tokens[i] == '>'
			|| *tokens[i] == R_DIR_APPEND || *tokens[i] == H_DOC)
		{
			if ((i == count - 1 || *tokens[i + 1] != WORD)
				|| (i == 0 && *tokens[i + 1] != WORD))
			{
				dup2(STDERR_FILENO, STDOUT_FILENO);
				printf(ERR_SYNTX_MSG_RE_H, "newline");
				dup2(STDOUT_FILENO, STDERR_FILENO);
				*exit_cd = 2;
				return (0);
			}
		}
		i++;
	}
	return (1);
}

int	check_syntax(char **values, int *tokens, int count, int *exit_cd)
{
	int	i;

	i = 0;
	while (i < count)
	{
		if (!check_pipe_err(values, count, exit_cd)
			|| !check_redir_err(values, count, tokens, exit_cd))
		{
			return (free(values), 0);
		}
		i++;
	}
	return (1);
}
