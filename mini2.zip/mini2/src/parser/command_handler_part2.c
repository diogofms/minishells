/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   command_handler_part2.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:49:09 by disilva           #+#    #+#             */
/*   Updated: 2024/08/10 01:03:53 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	print_commands_part2(char **cmds, int cmd_count, int i)
{
	if (i < cmd_count - 1)
		printf("Next command: %p\n", (void *)&cmds[i + 1]);
	else
		printf("Next command: NULL\n");
	if (i > 0)
		printf("Previous command: %p\n", (void *)&cmds[i - 1]);
	else
		printf("Previous command: NULL\n");
}

void	print_commands(char **cmds, int cmd_count, char *str_msg)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (cmd_count == 0 || cmds == NULL)
	{
		printf("The command list is empty or NULL\n");
		return ;
	}
	while (i < cmd_count)
	{
		printf("Arguments for command %d:\n", i + 1);
		if (cmds[i])
			print_array(&cmds[i], str_msg);
		else
			printf("  args: NULL\n");
		printf("fd_infile: %d\n", STDIN_FILENO);
		printf("fd_outfile: %d\n", STDOUT_FILENO);
		print_commands_part2(cmds, cmd_count, i);
		i++;
	}
}
