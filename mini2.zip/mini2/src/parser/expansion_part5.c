/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expansion_part5.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:08:12 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 02:41:58 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	remove_element(char **cmds, int *j)
{
	int	tmp;
	int	i;

	tmp = -1;
	i = *j - 1;
	while (*(cmds + ++tmp))
		;
	if (*(cmds + *j))
		free_str(*(cmds + *j));
	while (++i < tmp - 1)
		*(cmds + i) = *(cmds + i + 1);
	*(cmds + tmp - 1) = NULL;
	(*j)--;
}

void	print_2d_array(char **arr, char *msg)
{
	int	i;

	i = 0;
	printf("\n%s\n", msg);
	while (arr[i])
	{
		printf("%p [%d] ----- %s\n", (arr + i), i, arr[i]);
		i++;
	}
}

void	expansion_success_init_var(char *input, char ***cmds, int *index)
{
	*cmds = ft_split(input, '|');
	*index = 0;
}

int	expansion_success(char **envp, char *input, int *fds, int *exit_cd)
{
	int		index;
	int		j;
	int		exp_flag;
	char	**cmds;
	char	*str_part;

	(void)fds;
	(void)exit_cd;
	expansion_success_init_var(input, &cmds, &index);
	while (cmds[index])
	{
		if (DEBUG)
			print_2d_array(cmds, "before expansion");
		j = -1;
		exp_flag = 0;
		while (cmds[index][++j])
		{
			str_part = &(cmds[index][j]);
			if (!needs_expansion(envp, &str_part, &exp_flag))
			{
				remove_element(cmds, &j);
			}
			else
			{
				cmds[index] = str_part;
			}
			if (exp_flag)
			{
				cmds = combine_arrays(cmds, ft_split(cmds[index] + j, ' '),
						index, &exp_flag);
			}
		}
		if (DEBUG)
			print_2d_array(cmds, "after expansion");
		index++;
	}
	return (1);
}
