/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expansion_part2.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:07:43 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 18:06:02 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	free_str(char *str)
{
	if (str)
		free(str);
	str = NULL;
}

int	check_valid_env_char(char *str)
{
	return (ft_isalnum(*str) || ft_isalpha(*str) || *str == '_');
}

int	handle_exit_status(int exit_code, int *i, char **expanded_str)
{
	char	*exit_status;
	char	*new_expanded_str;

	exit_status = ft_itoa(exit_code);
	if (!exit_status)
		return (0);
	new_expanded_str = ft_strncat(*expanded_str, exit_status,
			ft_strlen(exit_status));
	free(exit_status);
	if (!new_expanded_str)
		return (0);
	*expanded_str = new_expanded_str;
	(*i)--;
	return (1);
}

int	needs_expansion(char **envp, char **arg, int *exp_flag)
{
	char	*expanded_str;

	expanded_str = NULL;
	if (successful_expansion(envp, *arg, &expanded_str, exp_flag))
	{
		free(*arg);
		*arg = expanded_str;
		return (1);
	}
	return (0);
}
