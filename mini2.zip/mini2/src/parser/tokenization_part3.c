/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenization_part3.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:05:54 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 05:07:49 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	build_token_part2(int *token_count, int *token_next, int *token_prev)
{
	if (*token_count < MAX_TOKENS - 1)
		token_next[*token_count] = *token_count + 1;
	else
		token_next[*token_count] = -1;
	if (*token_count > 0)
		token_prev[*token_count] = *token_count - 1;
	else
		token_prev[*token_count] = -1;
}

int	build_token(int type, char *val, int *token_info, char **token_vals)
{
	int	*token_types;
	int	*token_next;
	int	*token_prev;
	int	*token_count;

	token_types = &token_info[0];
	token_next = &token_info[MAX_TOKENS];
	token_prev = &token_info[2 * MAX_TOKENS];
	token_count = &token_info[3 * MAX_TOKENS];
	if (*token_count >= MAX_TOKENS)
		return (-1);
	token_types[*token_count] = type;
	if (type == '|')
		token_vals[*token_count] = ft_strdup("|");
	else if (type == R_DIR_APPEND)
		token_vals[*token_count] = ft_strdup(">>");
	else if (type == H_DOC)
		token_vals[*token_count] = ft_strdup("<<");
	else if (type == EOL)
		token_vals[*token_count] = ft_strdup("EOL");
	else
		token_vals[*token_count] = val;
	build_token_part2(token_count,
		token_next, token_prev);
	return ((*token_count)++);
}
