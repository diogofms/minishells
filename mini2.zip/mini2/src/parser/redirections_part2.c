/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirections_part2.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:01:32 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 06:41:37 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	execute_heredoc(int fd, char *delimiter, char **envp, int *exp_flag)
{
	char	*line;

	fd = open("obj/heredoc", O_CREAT | O_RDWR | O_TRUNC, 0644);
	if (fd == -1)
	{
		ft_putstr_fd(TERMINAL_NAME, STDERR_FILENO);
		return (-1);
	}
	while (1)
	{
		line = readline("> ");
		if (!line)
			break ;
		if (ft_strncmp(line, delimiter, ft_strlen(delimiter)) == 0)
		{
			free(line);
			break ;
		}
		if (needs_expansion(envp, &line, exp_flag))
		{
			ft_putstr_fd(line, fd);
			ft_putstr_fd("\n", fd);
		}
		free(line);
	}
	close(fd);
	fd = open("obj/heredoc", O_RDONLY);
	if (fd == -1)
	{
		ft_putstr_fd(TERMINAL_NAME, STDERR_FILENO);
		return (-1);
	}
	return (fd);
}

int	handle_input_heredoc(char **command_args, int *arg_index, int *input_fd,
		int *exit_code)
{
	char	*delimiter;
	char	**envp;
	int		exp_flag;

	delimiter = command_args[*arg_index + 1];
	envp = &command_args[0];
	exp_flag = 0;
	if (verify_fd_perm(delimiter) == 0)
	{
		*exit_code = 1;
		return (0);
	}
	else if (verify_fd_type(delimiter) == 0)
	{
		*exit_code = 126;
		return (0);
	}
	if (*input_fd != STDIN_FILENO)
		close(*input_fd);
	if (ft_strncmp(command_args[*arg_index], "<", 2) == 0)
	{
		*input_fd = open(delimiter, O_RDONLY);
	}
	else if (ft_strncmp(command_args[*arg_index], "<<", 2) == 0)
	{
		*input_fd = execute_heredoc(*input_fd, delimiter, envp, &exp_flag);
	}
	if (*input_fd == -1)
	{
		ft_putstr_fd(TERMINAL_NAME, STDERR_FILENO);
		*exit_code = 1;
		return (0);
	}
	remove_elements(command_args, arg_index, 2);
	return (1);
}

int	handle_redirections_conditions(char **command_args, t_redirections_hr *vars,
		int *file_descriptors, int *exit_code)
{
	if (ft_strchr(&command_args[vars->cmd_index][vars->arg_index], '>')
		&& ft_strlen(&command_args[vars->cmd_index][vars->arg_index]) <= 2)
	{
		if (!handle_output_append(&command_args[vars->cmd_index],
				&vars->arg_index, &file_descriptors[vars->cmd_index * 2 + 1]))
			return (*exit_code = 1, 0);
	}
	else if (ft_strchr(&command_args[vars->cmd_index][vars->arg_index], '<')
		&& ft_strlen(&command_args[vars->cmd_index][vars->arg_index]) <= 2)
	{
		if (!handle_input_heredoc(&command_args[vars->cmd_index],
				&vars->arg_index, &file_descriptors[vars->cmd_index * 2],
				exit_code))
			return (0);
	}
	return (1);
}

int	handle_redirections(char **command_args, int command_count,
		int *file_descriptors, int *exit_code)
{
	t_redirections_hr	vars;

	vars.cmd_index = 0;
	while (vars.cmd_index < command_count)
	{
		vars.arg_index = -1;
		while (command_args[vars.cmd_index]
			&& command_args[vars.cmd_index][++vars.arg_index])
		{
			if (!handle_redirections_conditions(command_args, &vars,
					file_descriptors, exit_code))
				return (0);
		}
		vars.cmd_index++;
	}
	return (1);
}
