/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expansion_part4.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:07:57 by disilva           #+#    #+#             */
/*   Updated: 2024/08/13 02:17:04 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	free_2d_array(char **array)
{
	char	**tmp;

	if (array == NULL)
		return ;
	tmp = array;
	while (*tmp)
	{
		free(*tmp);
		tmp++;
	}
	free(array);
}

int	combine_array1(char **array_1, int *i, char **new_array)
{
	*i = 0;
	while (array_1[*i])
	{
		new_array[*i] = ft_strdup(array_1[*i]);
		if (!new_array[*i])
		{
			free_2d_array(new_array);
			return (0);
		}
		(*i)++;
	}
	return (1);
}

int	combine_array2(char **array_2, int *i, char **new_array, int *j)
{
	*j = 0;
	while (array_2[*j])
	{
		new_array[*i] = ft_strdup(array_2[*j]);
		if (!new_array[*i])
		{
			free_2d_array(new_array);
			return (0);
		}
		(*i)++;
		(*j)++;
	}
	return (1);
}

char	**combine_arrays(char **array_1, char **array_2, int start,
		int *exp_flag)
{
	int		i;
	int		j;
	int		len;
	char	**new_array;

	(void)start;
	i = 0;
	j = 0;
	len = 0;
	while (array_1[len])
		len++;
	while (array_2[j])
		len++;
	new_array = (char **)malloc((len + 1) * sizeof(char *));
	if (!new_array)
		return (NULL);
	if (combine_array1(array_1, &i, new_array) == 0)
		return (NULL);
	if (combine_array2(array_2, &i, new_array, &j) == 0)
		return (NULL);
	new_array[i] = NULL;
	free_2d_array(array_1);
	free_2d_array(array_2);
	*exp_flag = 0;
	return (new_array);
}
