/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenization.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/24 00:45:05 by abekri            #+#    #+#             */
/*   Updated: 2024/08/12 02:21:01 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	ft_is_space(char c)
{
	return (c == 32 || (c >= 9 && c <= 13));
}

static int	handle_single_char_token(char *line, int *position, int *token_info,
		char **token_vals)
{
	char	current_char;

	current_char = line[*position];
	if (current_char == '|' || current_char == '<' || current_char == '>')
	{
		(*position)++;
		return (build_token(current_char, NULL, token_info, token_vals));
	}
	return (0);
}

static int	handle_double_char_token(char *line, int *position, int *token_info,
		char **token_vals)
{
	char	token_type;

	if ((line[*position] == '<' && line[*position + 1] == '<')
		|| (line[*position] == '>' && line[*position + 1] == '>'))
	{
		if (line[*position] == '<')
			token_type = H_DOC;
		else
			token_type = R_DIR_APPEND;
		*position += 2;
		return (build_token(token_type, NULL, token_info, token_vals));
	}
	return (0);
}

int	get_next_token(char *line, int *pos_info, int *token_info,
		char **token_vals)
{
	int	*position;

	position = &pos_info[0];
	while (*position < (int)ft_strlen(line))
	{
		skip_spaces(line, position);
		if (handle_single_char_token(line, position, token_info, token_vals))
		{
			return (1);
		}
		if (handle_double_char_token(line, position, token_info, token_vals))
		{
			return (1);
		}
		if (!ft_is_space(line[*position]))
		{
			return (extract_token_word(line, pos_info, token_info, token_vals));
		}
	}
	return (build_token(EOL, NULL, token_info, token_vals));
}
