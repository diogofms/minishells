/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenization_part2.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:03:14 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 05:07:34 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	manage_quotes(char *line, int *pos_info)
{
	int	*position;
	int	*isdouble_quote;
	int	*is_single_quote;

	position = &pos_info[0];
	isdouble_quote = &pos_info[1];
	is_single_quote = &pos_info[2];
	if (line[*position] == (char) '\'' && line[*position - 1] != (char) '\\'
		&& !*isdouble_quote && !*is_single_quote)
		*is_single_quote = 1;
	else if (line[*position] == (char) '\''
		&& line[*position - 1] != (char) '\\'
		&& !*isdouble_quote && *is_single_quote)
		*is_single_quote = 0;
	else if (line[*position] == (char) '\"'
		&& line[*position - 1] != (char) '\\'
		&& !*isdouble_quote && !*is_single_quote)
		*isdouble_quote = 1;
	else if ((line[*position] == (char) '\"')
		&& (line[*position - 1] != (char) '\\')
		&& *isdouble_quote && !*is_single_quote)
		*isdouble_quote = 0;
}

void	extract_token_word_part2(char *line, int *pos_info, t_token_etw	*vars)
{
	while (line[*(vars->position)])
	{
		if (line[*(vars->position)] == (char) '\''
			|| line[*(vars->position)] == (char) '\"')
			manage_quotes(line, pos_info);
		if (!*(vars->isdouble_quote) && ft_is_space(line[*(vars->position)])
			&& !*(vars->is_single_quote))
			break ;
		if (!*(vars->is_single_quote) && (line[*(vars->position)] == (char) '|'
				|| line[*(vars->position)] == (char) '<'
				|| line[*(vars->position)] == (char) '>')
			&& !*(vars->isdouble_quote))
			break ;
		(*(vars->position))++;
	}
}

int	extract_token_word(char *line, int *pos_info, int *token_info,
		char **token_vals)
{
	int			start;
	char		*word;
	t_token_etw	vars;

	vars.position = &pos_info[0];
	vars.isdouble_quote = &pos_info[1];
	vars.is_single_quote = &pos_info[2];
	start = *vars.position;
	extract_token_word_part2(line, pos_info, &vars);
	if (*(vars.isdouble_quote) || *(vars.is_single_quote))
		return (build_token(ERR, NULL, token_info, token_vals));
	word = ft_calloc(1, (*(vars.position) - start + 1));
	ft_strlcpy(word, line + start, *(vars.position) - start + 1);
	return (build_token(WORD, word, token_info, token_vals));
}

void	free_token_list(char **token_vals, int token_count)
{
	int	i;

	i = 0;
	while (i < token_count)
	{
		if (token_vals[i])
		{
			free(token_vals[i]);
		}
		if (token_vals[i] == NULL)
		{
			break ;
		}
		i++;
	}
	free(token_vals);
}

void	skip_spaces(char *line, int *position)
{
	while (ft_is_space(line[*position]))
	{
		(*position)++;
	}
}
