/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 22:46:27 by abekri            #+#    #+#             */
/*   Updated: 2024/08/13 02:53:34 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"
#include "../include/signals.h"

volatile sig_atomic_t	g_signal = 0;

void	main_loop(char *input, t_shell_config config)
{
	input = readline(config.terminal_name);
	while (input != NULL)
	{
		if (*input)
			add_history(input);
		free(input);
		rl_on_new_line();
		rl_replace_line("", 0);
		rl_redisplay();
		input = readline(config.terminal_name);
	}
}

int	main(int argc, char *argv[], char *envp[])
{
	t_shell_config	config;
	int				exit_msg;
	char			*input;
	char			*mini_env[MAX_ENV_VARS];

	(void)argv;
	exit_msg = 1;
	if (argc != 1 || !*envp)
		return (exit_msg);
	config.exit_cd = &exit_msg;
	config.envp = envp;
	// config.terminal_name = (char *)malloc(MAX_STRING_LEN * sizeof(char));
	setup_signal_handlers();
	start_info_ms(envp, &config.terminal_name, mini_env, config.exit_cd);
	start_iterm(&config);
	input = NULL;
	main_loop(input, config);
	rl_clear_history();
	free(config.terminal_name);
	printf("exit\n");
	return (*config.exit_cd);
}
