/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   adjust_shell_lvl_part3.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 22:00:05 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 21:45:00 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	update_env_with_new_level(char **env, char *new_lvl_str)
{
	int	ind;

	ind = 0;
	while (env[ind] && ft_strncmp(env[ind], "SHLVL=", 6) != 0)
		ind++;
	if (env[ind])
		free(env[ind]);
	env[ind] = new_lvl_str;
	if (!env[ind + 1])
		env[ind + 1] = NULL;
}

void	ft_update_shell_level(char **env, int increment)
{
	char	*old_lvl_str;
	char	*old_lvl_num;
	char	*new_lvl_num;
	char	*new_lvl_str;

	old_lvl_str = get_old_shell_level(env);
	if (!old_lvl_str)
		return ;
	old_lvl_num = extract_value(old_lvl_str);
	if (!old_lvl_num)
		return ;
	new_lvl_num = get_new_level_num(old_lvl_num, increment);
	new_lvl_str = ft_strjoin("SHLVL=", new_lvl_num);
	update_env_with_new_level(env, new_lvl_str);
	free_str(old_lvl_str);
	free_str(old_lvl_num);
	free_str(new_lvl_num);
	free_shell(env, new_lvl_str);
	
}
