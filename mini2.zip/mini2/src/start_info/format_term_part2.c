/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   format_term_part2.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:57:09 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 07:27:34 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

char	*format_prompt(char *user, char *node, char *path)
{
	char	*current_dir;
	char	*node_short;
	char	*dir_name;
	char	**parts;
	char	*output;

	parts = ft_split(node, '.');
	node_short = ft_strdup(parts[0]);
	free_2d_array(parts);
	current_dir = ft_strdup(ft_strrchr(path, '/') + 1);
	if (ft_strchr(current_dir, '\n'))
		dir_name = ft_substr(current_dir, 0, ft_strlen(current_dir) - 1);
	else
		dir_name = ft_strdup(current_dir);
	free_str(current_dir);
	output = ft_strdup(node_short);
	free_str(node_short);
	output = ft_strjoin(output, ":");
	output = ft_strjoin(output, dir_name);
	free_str(dir_name);
	output = ft_strjoin(output, " ");
	output = ft_strjoin(output, user);
	free_str(user);
	output = ft_strjoin(output, "$ ");
	return (output);
}

char	*format_iterm(char **environment)
{
	char	*param_cmd[2];
	char	*user;
	char	*current_dir;
	char	*node;
	char	output[BUFFER_SIZE];

	params_start(param_cmd, "/bin/hostname");
	perform_child_process_and_store_output(param_cmd, output);
	node = ft_strdup(output);
	get_args_empty(param_cmd);
	params_start(param_cmd, "/bin/pwd");
	perform_child_process_and_store_output(param_cmd, output);
	current_dir = ft_strdup(output);
	get_args_empty(param_cmd);
	user = ft_strdup(environment[find_var_index(environment, "USER")]);
	return (format_prompt(user, node, current_dir));
}
