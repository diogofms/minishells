/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   start_minishell_part2.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:55:02 by disilva           #+#    #+#             */
/*   Updated: 2024/08/13 02:20:57 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	add_missing_vars(char *mini_env[], int *i)
{
	if (!find_var_index(mini_env, "PWD"))
	{
		mini_env[(*i)++] = ft_strjoin("PWD=", getcwd(NULL, 0));
	}
	if (!find_var_index(mini_env, "OLDPWD"))
	{
		mini_env[(*i)++] = ft_strdup("OLDPWD");
	}
	if (!find_var_index(mini_env, "SHLVL"))
	{
		mini_env[(*i)++] = ft_strdup("SHLVL=1");
		mini_env[*i] = NULL;
	}
	else
	{
		ft_update_shell_level(mini_env, 1);
		mini_env[*i] = NULL;
	}
}

void	setup_env(char *orig_env[], char *mini_env[], int count)
{
	int	i;

	i = 0;
	while (orig_env[i] && i < count)
	{
		copy_env_var(orig_env, mini_env, &i);
	}
	// add_missing_vars(mini_env, &i);
	mini_env[i] = NULL;
}

void	free_mini_env(char *mini_env[])
{
	int	i;

	i = 0;
	while (mini_env[i] != NULL)
	{
		free (mini_env);
		i++;
	}
}

void	init_env(char **env, char *mini_env[], int count)
{
	int	i;

	i = 0;
	if (!is_var_set(env, "PWD"))
		count += 1;
	if (!is_var_set(env, "OLDPWD"))
		count += 1;
	if (!is_var_set(env, "SHLVL"))
		count += 1;
	// free (mini_env);
	// mini_env = (char **)malloc(sizeof(char *) * (count + 1));
	// if (!mini_env)
	// {
	// 	printf("Error: Failed to allocate memory for mini_env\n");
	// 	exit(1);
	// }
	setup_env(env, mini_env, count);
}
