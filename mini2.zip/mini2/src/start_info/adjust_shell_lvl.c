/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   adjust_shell_lvl.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/31 04:23:02 by abekri            #+#    #+#             */
/*   Updated: 2024/08/12 07:27:37 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	free_shell(char **env, char *s)
{
	int	ind;

	ind = 0;
	while (env[ind])
	{
		if (ft_strncmp(env[ind], "SHLVL=", 6) == 0)
		{
			free(env[ind]);
			env[ind] = s;
			return ;
		}
		ind++;
	}
	env[ind] = s;
	env[ind + 1] = NULL;
}

char	*bring_env(char **env, char const *n)
{
	int		ind;
	size_t	n_size;

	ind = 0;
	n_size = ft_strlen(n);
	while (env[ind])
	{
		if (ft_strncmp(env[ind], n, n_size) == 0 && env[ind][n_size] == '=')
		{
			return (env[ind]);
		}
		ind++;
	}
	return (NULL);
}

char	*extract_value(char *s)
{
	char	*val;
	int		ind;

	ind = 0;
	if (!s)
		return (NULL);
	while (s[ind] != '=')
		ind++;
	val = ft_strdup(s + ind + 1);
	free_str(s);
	return (val);
}

int	check_numeric_flag(char *s)
{
	int	numeric_flag;
	int	ind;

	numeric_flag = 1;
	ind = 0;
	while (s[ind] != '\0')
	{
		if (s[ind] < '0' || s[ind] > '9')
		{
			numeric_flag = 0;
			break ;
		}
		ind++;
	}
	return (numeric_flag);
}
