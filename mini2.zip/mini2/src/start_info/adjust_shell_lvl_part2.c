/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   adjust_shell_lvl_part2.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:59:18 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 07:27:41 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	check_alpha_flag(char *s)
{
	int	alpha_flag;
	int	ind;

	alpha_flag = 0;
	ind = 0;
	while (s[ind] != '\0')
	{
		if (ft_isalpha(s[ind]))
		{
			alpha_flag = 1;
			break ;
		}
		ind++;
	}
	return (alpha_flag);
}

int	handle_numeric_flag(char *s)
{
	if (ft_strcmp(s, "0") == 0)
	{
		return (1);
	}
	else if (ft_strcmp(s, "1") == 0)
	{
		return (2);
	}
	else
	{
		return (0);
	}
}

int	validate_string_content(char *s)
{
	int	numeric_flag;
	int	alpha_flag;

	numeric_flag = check_numeric_flag(s);
	alpha_flag = check_alpha_flag(s);
	if (numeric_flag)
	{
		return (handle_numeric_flag(s));
	}
	else
	{
		if (alpha_flag)
		{
			return (2);
		}
		else
		{
			return (1);
		}
	}
}

char	*get_old_shell_level(char **env)
{
	return (bring_env(env, "SHLVL"));
}

char	*get_new_level_num(char *old_lvl_num, int increment)
{
	int	old_lvl_val;
	int	new_lvl_val;

	if (validate_string_content(old_lvl_num) == 1)
		return (ft_strdup("0"));
	if (validate_string_content(old_lvl_num) == 2)
		return (ft_strdup("1"));
	old_lvl_val = ft_atoi(old_lvl_num);
	if (increment == 0)
	{
		new_lvl_val = old_lvl_val - 1;
	}
	else
	{
		new_lvl_val = old_lvl_val + 1;
	}
	if (new_lvl_val < 0)
		new_lvl_val = 0;
	return (ft_itoa(new_lvl_val));
}
