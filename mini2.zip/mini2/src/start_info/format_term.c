/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   format_term.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 20:09:28 by abekri            #+#    #+#             */
/*   Updated: 2024/08/12 07:27:31 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	params_start(char **args, char *s)
{
	int	i;

	i = 0;
	while (i < 1)
	{
		args[i] = ft_strdup(s);
		i++;
	}
	args[i] = NULL;
}

void	get_args_empty(char **args)
{
	int	i;

	if (args)
	{
		i = 0;
		while (args[i])
		{
			free_str(args[i]);
			i++;
		}
		free_2d_array(args);
	}
}

void	perform_child_process_and_store_output(char **args, char *output)
{
	int		pipefd[2];
	pid_t	pid;

	if (pipe(pipefd) == -1)
		return (perror("Pipe error"));
	pid = fork();
	if (pid == 0)
	{
		close(pipefd[0]);
		dup2(pipefd[1], STDOUT_FILENO);
		if (execve(args[0], args, NULL) == -1)
			return (perror("execve error"));
	}
	else
	{
		wait(NULL);
		close(pipefd[1]);
		read(pipefd[0], output, BUFFER_SIZE);
		close(pipefd[0]);
		dup2(1, STDOUT_FILENO);
	}
}
