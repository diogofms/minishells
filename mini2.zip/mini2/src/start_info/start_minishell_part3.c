/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   start_minishell_part3.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:56:06 by disilva           #+#    #+#             */
/*   Updated: 2024/08/13 02:41:10 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	count_env_vars(char **env)
{
	int	len;

	len = 0;
	while (env[len])
		len++;
	return (len);
}

char	*get_cwd(void)
{
	char	*cwd;

	cwd = getcwd(NULL, 0);
	if (cwd == NULL)
		return (ft_strdup(""));
	return (cwd);
}

char	*get_home(void)
{
	char	*cwd;
	char	*home;
	char	**parts;
	char	*tmp;

	cwd = getcwd(NULL, 0);
	if (cwd == NULL)
		return (ft_strdup(""));
	parts = ft_split(cwd, '/');
	tmp = ft_strdup("/");
	home = ft_strjoin(tmp, parts[0]);
	free(tmp);
	tmp = ft_strjoin(home, "/");
	free(home);
	home = ft_strjoin(tmp, parts[1]);
	free(tmp);
	free_2d_array(parts);
	if (home == NULL)
		return (free_str(cwd), ft_strdup(""));
	free_str(cwd);
	return (home);
}

void	start_info_ms(char **env, char **term_name, char *mini_env[],
		int *exit_code)
{
	int		len;
	char	*path;
	char	*home;

	len = count_env_vars(env);
	// mini_env = (char **)malloc(sizeof(char *) * (len + 3));
	// if (!mini_env)
	// {
	// 	printf("Error: malloc failed for mini_env\n");
	// 	*exit_code = 1;
	// 	return ;
	// }
	init_env(env, mini_env, len);
	*term_name = NULL;
	*exit_code = 0;
	*term_name = (char *)malloc((MAX_STRING_LEN) * sizeof(char));
	if (!*term_name)
	{
		printf("Error: malloc failed for term_name\n");
		free_mini_env(mini_env);
		*exit_code = 1;
		return ;
	}
	path = get_cwd();
	home = get_home();
	if (DEBUG)
	{
		print_2d_array(mini_env, "ENVIRONMENT VARIABLES");
		printf("%s", format_iterm(mini_env));
	}
	else
	{
		printf("minishell-0.1$ ");
	}
	free(path);
	free(home);
	// free_mini_env(mini_env);
}
