/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   terminal_part2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 21:51:48 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 04:55:29 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/minishell.h"

void	setup_command_context(t_command_context *context)
{
	context->input_line = NULL;
	context->command_count = 0;
	context->input_fd = 0;
	context->output_fd = 1;
	initialize_command_list(context->command_list);
}

void	finalize(char *pwd, char *home)
{
	free(pwd);
	free(home);
}

int	read_input(t_shell_config *config, t_command_context *context)
{
	char	*readline_input;

	readline_input = readline(config->terminal_name);
	if (!readline_input)
	{
		return (0);
	}
	if (readline_input[0] == '\0')
	{
		free(readline_input);
		return (1);
	}
	add_history(readline_input);
	context->input_line = readline_input;
	return (2);
}

void	process_input_part2(int *i,
char cmds[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE])
{
	int	j;

	*i = 0;
	while (*i < MAX_COMMANDS)
	{
		j = 0;
		while (j < MAX_ARGS)
		{
			memset(cmds[*i][j], 0, BUFFER_SIZE);
			j++;
		}
		(*i)++;
	}
}

void	process_input(t_command_context *context, t_shell_config *config)
{
	int		cmd_count;
	int		i;
	char	cmds[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE];

	cmd_count = 0;
	process_input_part2(&i, cmds);
	if (check_parsing(context->input_line, config->envp, config->fds,
			config->exit_cd))
	{
		while (i < MAX_COMMANDS && cmds[i][0][0] != '\0')
		{
			cmd_count++;
			i++;
		}
		if (cmd_count > 0 && cmds[0][0][0])
			execution_command(cmds, cmd_count, config->fds, config->exit_cd);
		else
			handle_error(context->input_line, config->exit_cd);
	}
	else
		handle_error(context->input_line, config->exit_cd);
}
