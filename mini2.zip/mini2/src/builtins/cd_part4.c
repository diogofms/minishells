/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cd_part4.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/10 21:41:09 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 21:26:02 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

char	*build_home_directory(char **envp, char *future_wd)
{
	char	*home;
	int		i;
	int		j;

	home = retrieve_env_variable(envp, "HOME");
	if (!home)
		home = ft_strdup("");
	i = ft_strlen(home);
	while (i > -1 && home[i] != '=')
		i--;
	future_wd = malloc(ft_strlen(home) - i);
	j = 0;
	while (home[++i] != '\0')
		future_wd[j++] = home[i];
	future_wd[j] = '\0';
	free(home);
	return (future_wd);
}

char	*extract_subpath(char *full_path)
{
	int		index;
	int		sub_index;
	char	*sub_path;

	index = 0;
	while (full_path[index] != '\0' && full_path[index] != '=')
		index++;
	sub_path = malloc((ft_strlen(full_path) - index) + 1);
	if (!sub_path)
		perror("extract_subpath.c line 46");
	sub_index = 0;
	index++;
	while (full_path[index] != '\0')
		sub_path[sub_index++] = full_path[index++];
	sub_path[sub_index] = '\0';
	free_str(full_path);
	return (sub_path);
}

void	change_to_previous_dir_from_env(char **envp, char **cmds_args,
		int out_fd, int *exit_cd)
{
	char	*oldpwd;
	char	*cwd;

	if (!find_minus_in_envp(envp, "OLDPWD"))
	{
		print_error_message(cmds_args[0], NULL, 3, exit_cd);
		return ;
	}
	cwd = getcwd(NULL, 0);
	oldpwd = ft_getenv(envp, "OLDPWD=");
	oldpwd = extract_subpath(oldpwd);
	update_old_env_variable(envp, cwd);
	chdir(oldpwd);
	update_new_path(envp, oldpwd);
	ft_putendl_fd(oldpwd, out_fd);
	*exit_cd = 0;
}

void	handle_cd_part1(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		char **env_vars, int *exit_cd)
{
	if (command_list[0][1] && ft_strncmp(command_list[0][1], "-", 1) == 0)
		change_to_previous_dir_from_env(env_vars, (char **)command_list[0],
			STDOUT_FILENO, exit_cd);
	else if (command_list[0][1] && ft_strncmp(command_list[0][1], "..", 2) == 0
		&& ft_strlen(command_list[0][1]) == 2)
	{
		change_to_prev_dir(env_vars, exit_cd);
		update_new_path(env_vars, getcwd(NULL, 0));
	}
	else if (command_list[0][1] && ft_strncmp(command_list[0][1], "~/", 2) == 0)
	{
		change_to_tilda_path(env_vars, command_list, exit_cd);
		update_new_path(env_vars, getcwd(NULL, 0));
	}
}

void	handle_cd_part2(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		char **env_vars, int *exit_cd)
{
	if (!command_list[0][1] || ft_strncmp(command_list[0][1], "~", 2) == 0
		|| ft_strncmp(command_list[0][1], ";", 2) == 0)
	{
		change_to_home_dir(env_vars, command_list, exit_cd);
		update_new_path(env_vars, getcwd(NULL, 0));
	}
	else if (command_list[0][1] && ft_strncmp(command_list[0][1], "/Users/",
			7) != 0)
	{
		change_to_rel_path(command_list, env_vars, exit_cd);
		update_new_path(env_vars, getcwd(NULL, 0));
	}
	else if (command_list[0][1] && ft_strncmp(command_list[0][1], "/", 1) == 0)
	{
		change_to_abs_path(command_list, env_vars, exit_cd);
		update_new_path(env_vars, getcwd(NULL, 0));
	}
	else
	{
		print_error_message_extra("cd: ", command_list[0][1], 2, exit_cd);
	}
}

void	ft_cd(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		char **env_vars, int *exit_cd)
{
	if (ft_strncmp(command_list[0][0], "cd", 3) != 0)
	{
		print_error_message_exit(command_list[0][0], 1, exit_cd);
	}
	else
	{
		handle_cd_part1(command_list, env_vars, exit_cd);
		handle_cd_part2(command_list, env_vars, exit_cd);
	}
}
