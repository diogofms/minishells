/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exit.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 17:59:16 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 21:25:35 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	get_envp_length(char **envp)
{
	int	size;

	size = 0;
	while (envp[size])
		size++;
	return (size);
}

int	is_numeric_string(char *str)
{
	int	i;
	int	flag;

	i = -1;
	flag = 0;
	while (str[++i] != '\0')
	{
		if ((!ft_isdigit(str[i]) && str[i] != '+' && str[i] != '-') || flag > 1)
			return (0);
		if (str[i] == '+' || str[i] == '-')
			flag++;
	}
	return (1);
}

void	terminate_shell(char **env, int *fds, int *exit_cd, int c)
{
	ft_putendl_fd("exit", 1);
	free_2d_array(env);
	free_2d_array((char **)fds);
	*exit_cd = c;
	exit(c);
}

long long	string_to_long_long(char *str)
{
	long long	i;
	long long	sign;
	long long	result;

	i = 0;
	sign = 1;
	if (str[i] == '-')
	{
		sign = -1;
		i++;
	}
	result = 0;
	while (str[i] != '\0' && str[i] >= 48 && str[i] <= 57)
	{
		result = (result * 10) + (str[i] - 48);
		i++;
	}
	return (result * sign);
}

void	ft_exit(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		int *fds, int *exit_cd)
{
	int		args_len;
	char	**env;

	env = (char **)command_list[0];
	ft_update_shell_level(env, 0);
	if (ft_strncmp(command_list[0][0], "exit", 5) != 0)
		print_error_message_exit(command_list[0][0], 1, exit_cd);
	else
	{
		args_len = count_env_vars((char **)command_list[0]);
		if (args_len > 1 && !is_numeric_string(command_list[0][1]))
		{
			ft_putendl_fd("exit", 1);
			print_error_message("exit: ", command_list[0][1], 1, exit_cd);
		}
		else if (args_len == 2 && strncmp(command_list[0][0], "exit", 5) == 0)
		{
			terminate_shell(env, fds, exit_cd,
				string_to_long_long(command_list[0][1]));
		}
		else if (args_len > 2 && is_numeric_string(command_list[0][1]))
		{
			print_error_message("exit", NULL, 2, exit_cd);
		}
		else if (args_len == 1 && strncmp(command_list[0][0], "exit", 5) == 0)
			terminate_shell(env, fds, exit_cd, *exit_cd);
		else
			print_error_message_exit(command_list[0][0], 1, exit_cd);
	}
}
