/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   export_part2.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/11 00:50:27 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 00:15:49 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	print_export_without_args(int out_fd, char *entry, int flag)
{
	int		j;
	char	*key;

	if (flag == 1)
	{
		ft_putstr_fd("declare -x ", out_fd);
		j = 0;
		while (entry[j] != '\0' && entry[j] != '=')
			ft_putchar_fd(entry[j++], out_fd);
		ft_putstr_fd("=\"", out_fd);
		while (entry[j] != '\0')
			ft_putchar_fd(entry[j++], out_fd);
		ft_putstr_fd("\"\n", out_fd);
	}
	else if (flag == 2)
	{
		key = "OLDPWD";
		if (ft_strncmp(entry, key, ft_strlen(key)) != 0)
		{
			ft_putstr_fd("declare -x ", out_fd);
			ft_putstr_fd(entry, out_fd);
			ft_putstr_fd("\n", out_fd);
		}
	}
}

void	export_no_args(char **envp, int out_fd)
{
	char	**alpha_order;
	int		i;

	alpha_order = malloc((count_env_vars(envp) + 1) * sizeof(char *));
	alpha_order = ft_sort_env_vars(envp, alpha_order);
	i = count_env_vars(alpha_order);
	while (--i > -1)
	{
		if (ft_strchr(alpha_order[i], '=') != NULL
			&& ft_strlen(alpha_order[i]) != 0)
			print_export_without_args(out_fd, alpha_order[i], 1);
		else if (ft_strlen(alpha_order[i]) != 0)
			print_export_without_args(out_fd, alpha_order[i], 2);
	}
	free_2d_array(alpha_order);
}

void	update_env_with_args(char **envp, char args[MAX_ARGS][BUFFER_SIZE],
		t_export_ues *vars)
{
	if (ft_find_in_envp(envp, vars->var) == -1)
	{
		if (ft_strnstr(args[vars->j], "+=", ft_strlen(args[vars->j])) != NULL)
			ft_add_plus_minus(envp, vars->i, args[vars->j]);
		else
			envp[(vars->i)] = ft_strdup(args[vars->j]);
		(vars->i)++;
		envp[(vars->i)] = NULL;
	}
	else
	{
		if (!ft_strchr(envp[ft_find_in_envp(envp, vars->var)], '=')
			&& (ft_strchr(args[vars->j], '=') > ft_strchr(args[vars->j], '+')))
			ft_append_to_env_var_ex(envp, -1, args[vars->j], vars->var);
		else if (ft_has_value_after_equal(args[vars->j]) != 0)
			ft_replace_env_var(envp, args[vars->j],
				ft_find_in_envp(envp, vars->var));
		else if (ft_strchr(args[vars->j], '=') && ft_strchr(args[vars->j], '+')
			&& (ft_strchr(args[vars->j], '=') > ft_strchr(args[vars->j], '+')))
			ft_append_to_env_var(envp, -1, args[vars->j], vars->var);
	}
}

void update_envp_size(char **envp, char args[MAX_ARGS][BUFFER_SIZE]) {
    t_export_ues vars;
    int args_len;

    // First, count the number of non-null strings in args
    args_len = 0;
    while (args[args_len][0] != '\0' && args_len < MAX_ARGS) {
        args_len++;
    }

    // Calculate new size for envp array
    vars.new_envp_size = count_env_vars(envp) + args_len;
    vars.new_envp = calloc(vars.new_envp_size + 1, sizeof(char *)); // +1 for NULL terminator
    if (!vars.new_envp) {
        // Handle allocation failure
        return;
    }

    // Copy existing environment variables
    vars.i = -1;
    while (envp[++vars.i] != NULL) {
        vars.new_envp[vars.i] = ft_strdup(envp[vars.i]);
    }
    free_2d_array(envp);

    // Allocate new envp array
    envp = calloc(vars.new_envp_size + 1, sizeof(char *)); // +1 for NULL terminator
    if (!envp) {
        // Handle allocation failure
        free_2d_array(vars.new_envp);
        return;
    }

    // Copy new environment variables
    vars.i = -1;
    while (vars.new_envp[++vars.i] != NULL) {
        envp[vars.i] = ft_strdup(vars.new_envp[vars.i]);
    }
    envp[vars.new_envp_size] = NULL;
    free_2d_array(vars.new_envp);

    // Update envp with new variables
    vars.j = 0;
    while (vars.j < args_len) {
        if (handle_export_errors(args, vars.j) == 0) {
            vars.j++;
            continue;
        }
        vars.var = extract_env_var_name(args[vars.j]);
        update_env_with_args(envp, args, &vars);
        free(vars.var);
        vars.j++;
    }
}




void ft_export(char args[MAX_ARGS][BUFFER_SIZE], char **envp, int *exit_cd, int out_fd) {
    if (ft_strncmp(args[0], "export", 7) != 0) {
        print_error_message_exit(args[0], 1, exit_cd); // Pass exit_cd instead of args[0]
    } else if (args[1] == NULL && strlen(args[0]) == 6) {
        export_no_args(envp, out_fd);
        return;
    }
    update_envp_size(envp, args);
    *exit_cd = ft_calculate_export_exit_status(args);
}

