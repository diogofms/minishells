/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cd_part2.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/10 21:40:04 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 02:38:51 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	change_to_rel_path(
		char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		char **env_vars, int *exit_cd)
{
	char	*temp;
	char	*cwd;
	char	*future_wd;

	cwd = getcwd(NULL, 0);
	temp = ft_strjoin(cwd, "/");
	future_wd = ft_strjoin(temp, command_list[0][1]);
	if (access(future_wd, F_OK | X_OK) == 0)
	{
		update_old_env_variable(env_vars, cwd);
		chdir(future_wd);
		*exit_cd = 0;
	}
	else
	{
		print_error_message_extra("cd: ", command_list[0][1], 2, exit_cd);
	}
	free_str(temp);
	free_str(future_wd);
}

void	change_to_abs_path(
		char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		char **env_vars, int *exit_cd)
{
	char	*cwd;

	cwd = getcwd(NULL, 0);
	if (access(command_list[0][1], F_OK | X_OK) == 0)
	{
		update_old_env_variable(env_vars, cwd);
		chdir(command_list[0][1]);
		*exit_cd = 0;
	}
	else
	{
		print_error_message_extra("cd: ", command_list[0][1], 2, exit_cd);
	}
}

void	change_to_home_dir(char **env_vars,
		char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE], int *exit_cd)
{
	char	*future_wd;
	char	*cwd;

	if (!check_in_envp(env_vars, "HOME") && command_list[0][1] == NULL)
	{
		print_error_message_exit("cd", 4, exit_cd);
		return ;
	}
	future_wd = NULL;
	cwd = getcwd(NULL, 0);
	future_wd = build_home_directory(env_vars, future_wd);
	if (ft_strlen(command_list[0][0]) == 2)
	{
		update_old_env_variable(env_vars, cwd);
		chdir(future_wd);
		*exit_cd = 0;
	}
	else
	{
		print_error_message_exit(command_list[0][0], 1, exit_cd);
	}
	free_str(future_wd);
}

int	get_prev_dir_len(const char *cwd)
{
	int	i;

	i = strlen(cwd) - 1;
	while (i > 0 && cwd[i] != '/')
		i--;
	if (i == 0)
		return (1);
	else
		return (i);
}
