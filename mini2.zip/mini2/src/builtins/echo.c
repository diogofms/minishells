/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   echo.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 17:59:30 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 00:57:03 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

char *ft_getenv(char **envp, const char *name) {
    int i = 0;
    size_t name_len = strlen(name);

    while (envp[i]) {
        if (strncmp(envp[i], name, name_len) == 0 && envp[i][name_len] == '=') {
            return envp[i];
        }
        i++;
    }
    return NULL;
}

int	check_echo_flag(char *s)
{
	int	i;

	if (ft_strncmp(s, "-n", 2) == 0)
	{
		i = 1;
		while (s[++i] != '\0' && s[0] == '-' && s[i] == 'n')
			if (s[i] != 'n' && i > 1)
				return (0);
		if (i == (int)ft_strlen(s))
			return (1);
	}
	return (0);
}

void	handle_echo_newline(int out_fd, int *exit_code, int flag)
{
	if (flag != 0)
		ft_putstr_fd("\n", out_fd);
	*exit_code = 0;
}

char	*trim_environment_path(char *path)
{
	char	*tmp;
	int		i;
	int		j;

	i = 0;
	while (path[i] != '\0' && path[i] != '=')
		i++;
	tmp = malloc((ft_strlen(path) - i) + 1);
	if (!tmp)
		perror("find_path.c line 46");
	j = 0;
	i++;
	while (path[i] != '\0')
		tmp[j++] = path[i++];
	tmp[j] = '\0';
	free_str(path);
	return (tmp);
}

void	print_tilda_in_echo(char **env_vars, int params[])
{
	t_echo_ptie	vars;

	vars.out_fd = params[0];
	vars.home = ft_getenv(env_vars, "HOME");
	if (!vars.home)
	{
		ft_putstr_fd("", vars.out_fd);
		return ;
	}
	else
		vars.trimmed_home = trim_environment_path(vars.home);
	vars.i = ft_strlen(vars.trimmed_home);
	while (vars.i > -1 && vars.trimmed_home[vars.i] != '=')
		vars.i--;
	vars.print = malloc(ft_strlen(vars.trimmed_home) - vars.i);
	vars.j = -1;
	while (vars.trimmed_home[++vars.i] != '\0')
		vars.print[++vars.j] = vars.trimmed_home[vars.i];
	vars.print[++vars.j] = '\0';
	ft_putstr_fd(vars.print, vars.out_fd);
	free(vars.trimmed_home);
	free(vars.print);
}

void	print_echo_arguments(char args[MAX_ARGS][BUFFER_SIZE], char **env_vars,
		int params[], int index)
{
	int	out_fd;

	out_fd = params[0];
	if (ft_strncmp(args[index], "~", 2) == 0)
		print_tilda_in_echo(env_vars, params);
	else
		ft_putstr_fd(args[index], out_fd);
}
