/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   echo_part2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/11 00:37:49 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 02:31:06 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	execute_echo_args(
		char args[MAX_ARGS][BUFFER_SIZE],
			char **env_vars, int params[], t_echo_ee *vars)
{
	while (args[++vars->i][0] != '\0')
	{
		if (check_echo_flag(args[vars->i]) && vars->no_flags != 0)
			vars->suppress_newline = 0;
		else
		{
			vars->no_flags = 0;
			print_echo_arguments(args, env_vars, params, vars->i);
			if (args[vars->i + 1][0] == '\0')
				break ;
			ft_putstr_fd(" ", vars->out_fd);
		}
	}
}

void	ft_echo(
		char args[MAX_ARGS][BUFFER_SIZE], char **env_vars, int params[])
{
	t_echo_ee	vars;

	vars.no_flags = params[1];
	vars.out_fd = params[0];
	vars.exit_code = &params[2];
	vars.i = 0;
	vars.suppress_newline = 1;
	if (ft_strncmp(args[0], "echo", 5) == 0)
	{
		execute_echo_args(args, env_vars, params, &vars);
		handle_echo_newline(vars.out_fd, vars.exit_code, vars.suppress_newline);
	}
	else
		print_error_message_exit(args[0], 1, vars.exit_code);
}
