/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   export_part3.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/11 00:50:24 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 02:34:33 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	ft_find_in_envp(char **envp, char *var)
{
	int	i;

	i = -1;
	while (envp[++i] != NULL)
	{
		if (ft_strncmp(envp[i], var, ft_strlen(var)) == 0
			&& (envp[i][ft_strlen(var)] == '='
				|| envp[i][ft_strlen(var)] == '\0'
				|| (envp[i][ft_strlen(var)] == '+' && envp[i][ft_strlen(var)
					+ 1] == '=')))
			return (i);
	}
	return (-1);
}

void	print_error_message_export(char *message1, char *message2, int code,
		char args[MAX_ARGS][BUFFER_SIZE])
{
	ft_putstr_fd("minishell: ", 2);
	ft_putstr_fd(message1, 2);
	ft_putstr_fd(message2, 2);
	for (int i = 0; i < MAX_ARGS && args[i][0] != '\0'; i++)
	{
		ft_putstr_fd(" ", 2);
		ft_putstr_fd(args[i], 2);
	}
	if (code == 1)
	{
		ft_putendl_fd(": command not found", 2);
	}
	else if (code == 3)
	{
		ft_putendl_fd(": not enough arguments", 2);
	}
	else if (code == 2)
	{
		ft_putendl_fd(": No such file or directory", 2);
	}
	else if (code == 4)
	{
		ft_putendl_fd("': not a valid identifier", 2);
	}
}

int	handle_export_errors(char args[MAX_ARGS][BUFFER_SIZE], int i)
{
	if (args[1][0] == '-')
	{
		if (i != 1)
			return (0);
		ft_putstr_fd("minishell: ", 2);
		ft_putstr_fd("export: -", 2);
		ft_putchar_fd(args[i][1], 2);
		ft_putendl_fd(": invalid option", 2);
		ft_putendl_fd(ERROR_EXPORT_MSG, 2);
		return (0);
	}
	else if (!ft_check_export_string(args[i]))
	{
		print_error_message_export("export: `", args[i], 4, args);
		return (0);
	}
	else if (isdigit(args[i][0]) == 1)
	{
		print_error_message_export("export: `", args[i], 4, args);
		return (0);
	}
	return (1);
}

char	*extract_env_var_name(char *env_line)
{
	int		i;
	char	*var;

	i = 0;
	while (env_line[i] != '\0' && env_line[i] != '+' && env_line[i] != '=')
		i++;
	var = malloc(i);
	i = -1;
	while (env_line[++i] != '\0' && env_line[i] != '+' && env_line[i] != '=')
		var[i] = env_line[i];
	var[i] = '\0';
	return (var);
}
