/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 17:59:25 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 02:47:38 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	ft_env(char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE],
		char **env_vars, int *exit_code, int out_fd)
{
	int	i;

	i = -1;
	if (ft_strncmp(command_list[0][0], "env", 4) == 0)
	{
		while (env_vars[++i] != NULL)
		{
			if (ft_strchr(env_vars[i], '=') != NULL)
			{
				ft_putendl_fd(env_vars[i], out_fd);
			}
		}
		*exit_code = 0;
	}
	else
	{
		print_error_message_exit(command_list[0][0], 1, exit_code);
	}
}
