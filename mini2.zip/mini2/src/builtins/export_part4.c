/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   export_part4.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/11 00:50:16 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 02:47:25 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

char	**ft_sort_env_vars(char **envp, char **sorted_vars)
{
	char	*temp;
	int		i;
	int		j;

	i = -1;
	while (envp[++i] != NULL)
		sorted_vars[i] = ft_strdup(envp[i]);
	sorted_vars[i] = NULL;
	i = -1;
	while (sorted_vars[++i] != NULL)
	{
		j = -1;
		while (sorted_vars[++j + 1] != NULL)
		{
			if (ft_strncmp(sorted_vars[j], sorted_vars[j + 1],
					ft_strlen(sorted_vars[j + 1])) < 0)
			{
				temp = sorted_vars[j];
				sorted_vars[j] = sorted_vars[j + 1];
				sorted_vars[j + 1] = temp;
			}
		}
	}
	return (sorted_vars);
}

int	ft_check_export_string(char *s)
{
	int	i;

	i = -1;
	while (s[++i] != '\0' && s[i] != '=' && !(s[i] == '+' && s[i + 1] == '='))
		if (ft_isalnum(s[i]) != 1 && s[i] != '_')
			return (0);
	return (1);
}

int	ft_calculate_export_exit_status(char args[MAX_ARGS][BUFFER_SIZE])
{
	int	i;

	if (args[1][0] == '-')
		return (2);
	i = 0;
	while (args[++i] != NULL)
	{
		if (ft_isdigit(args[i][0]) == 1)
			return (1);
		else if (!ft_check_export_string(args[i]))
			return (1);
	}
	return (0);
}

int	ft_has_value_after_equal(char *arg)
{
	int	i;

	i = 0;
	while (arg[i] != '\0' && arg[i] != '=')
		i++;
	if (arg[i] == '\0')
		return (0);
	return (1);
}
