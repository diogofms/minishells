/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cd_part3.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/10 21:40:41 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 02:11:40 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

char	*remove_tilda_from_path(const char *s)
{
	char	*result;
	int		i;
	int		j;

	i = 0;
	result = malloc(ft_strlen(s) + 1);
	i = 0;
	j = 0;
	while (s[++i] != '\0')
		result[j++] = s[i];
	result[j] = '\0';
	return (result);
}

void	update_old_env_variable(char **envp, const char *owd)
{
	modify_env_variable(envp, "OLDPWD=", owd);
}

void	update_new_path(char **envp, const char *pwd)
{
	int	i;

	if (!check_in_envp(envp, "PWD"))
	{
		modify_env_variable(envp, "PWD=", pwd);
		i = 0;
		while (envp[i] != NULL)
			i++;
		envp[i + 1] = NULL;
	}
	else
	{
		modify_env_variable(envp, "PWD=", pwd);
	}
}

int	find_minus_in_envp(char **envp, const char *var)
{
	int	i;

	i = 0;
	while (envp[i] != NULL)
	{
		if (ft_strncmp(envp[i], var, ft_strlen(var)) == 0
			&& envp[i][ft_strlen(var)] == '=')
			return (i);
		i++;
	}
	return (0);
}
