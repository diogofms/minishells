/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   unset_part2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/11 00:38:35 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 02:43:53 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	ft_unset(char args[MAX_ARGS][BUFFER_SIZE], char **envp, int *exit_code)
{
	int	params[1];
	int	env_size;
	int	idx;

	if (ft_strncmp(args[0], "unset", 6) != 0)
	{
		print_error_message_exit("Unset: ", 1, exit_code);
		return ;
	}
	else if (args[1][0] == '\0')
	{
		return ;
	}
	handle_unset_errors(args, exit_code);
	idx = 0;
	while (args[++idx][0] != '\0')
	{
		if (find_env_var_index(envp, args[idx], params) != -1)
		{
			env_size = count_env_vars(envp);
			remove_element(envp, &params[0]);
			envp[env_size] = NULL;
		}
	}
	*exit_code = ft_calculate_export_exit_status(args);
}
