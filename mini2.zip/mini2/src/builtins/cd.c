/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cd.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 17:59:35 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 00:23:45 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

int	check_in_envp(char **envp, const char *var)
{
	int	i;

	i = 0;
	while (envp[i] != NULL)
	{
		if (ft_strncmp(envp[i], var, ft_strlen(var)) == 0
			&& envp[i][ft_strlen(var)] == '=')
			return (1);
		i++;
	}
	return (0);
}

void	modify_env_variable(char **envp, const char *var, const char *value)
{
	int		i;
	char	*new_var;

	i = 0;
	while (envp[i] != NULL && ft_strncmp(envp[i], var, ft_strlen(var)) != 0)
		i++;
	if (envp[i] != NULL)
		free(envp[i]);
	new_var = malloc(ft_strlen(var) + ft_strlen(value) + 1);
	sprintf(new_var, "%s%s", var, value);
	envp[i] = new_var;
}

char	*retrieve_env_variable(char **envp, const char *var)
{
	int		i;
	size_t	len;

	i = 0;
	len = ft_strlen(var);
	while (envp[i] != NULL)
	{
		if (ft_strncmp(envp[i], var, len) == 0 && envp[i][len] == '=')
			return (envp[i] + len + 1);
		i++;
	}
	return (NULL);
}

void change_to_tilda_path(char **env_vars,
    char command_list[MAX_COMMANDS][MAX_ARGS][BUFFER_SIZE], int *exit_cd)
{
    char *temp;
    char *cwd;
    char *path;
    char *home;

    home = NULL;
    cwd = getcwd(NULL, 0);
    home = build_home_directory(env_vars, home);
    temp = remove_tilda_from_path(command_list[0][1]);
    path = ft_strjoin(home, temp);
    if (access(path, F_OK | X_OK) == 0)
    {
        update_old_env_variable(env_vars, cwd);
        chdir(path);
        update_new_path(env_vars, path);
        *exit_cd = 0;
    }
    else
    {
        print_error_message_extra("cd: ", command_list[0][1], 2, exit_cd);
    }
    free_str(home);
    free_str(temp);
    free_str(path);
}


void	change_to_prev_dir(char **envp, int *exit_cd)
{
	char	*cwd;
	int		future_wd_size;
	char	*future_wd;

	cwd = getcwd(NULL, 0);
	future_wd_size = get_prev_dir_len(cwd);
	future_wd = malloc(future_wd_size + 1);
	strncpy(future_wd, cwd, future_wd_size);
	future_wd[future_wd_size] = '\0';
	update_old_env_variable(envp, cwd);
	chdir(future_wd);
	*exit_cd = 0;
	free_str(future_wd);
	free_str(cwd);
}
