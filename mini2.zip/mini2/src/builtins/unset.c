/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   unset.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abekri <abekri@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 17:58:56 by disilva           #+#    #+#             */
/*   Updated: 2024/08/12 02:34:18 by abekri           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	print_error_message_extra(char *message1, char *message2, int c,
		int exit_code_array[])
{
	ft_putstr_fd("minishell: ", 2);
	ft_putstr_fd(message1, 2);
	ft_putstr_fd(message2, 2);
	if (c == 1)
	{
		ft_putendl_fd(": command not found", 2);
		exit_code_array[0] = 127;
	}
	else if (c == 2)
	{
		ft_putendl_fd(": No such file or directory", 2);
		exit_code_array[0] = 1;
	}
	else if (c == 3)
	{
		ft_putendl_fd(": not enough arguments", 2);
		exit_code_array[0] = 1;
	}
	else if (c == 4)
	{
		ft_putendl_fd("': not a valid identifier", 2);
		exit_code_array[0] = 1;
	}
}

int	find_env_var_index(char **envp, char *var, int params[])
{
	int	*index;

	index = &params[0];
	*index = -1;
	while (envp[++(*index)] != NULL)
	{
		if (ft_strncmp(var, envp[*index], ft_strlen(var)) == 0
			&& (envp[*index][ft_strlen(var)] == '='
			|| envp[*index][ft_strlen(var)] == '\0'))
		{
			return (*index);
		}
	}
	return (-1);
}

int	is_valid_unset_identifier(char *str)
{
	int	idx;

	idx = -1;
	while (str[++idx] != '\0')
	{
		if (ft_isalnum(str[idx]) != 1 && str[idx] != '_')
		{
			return (0);
		}
	}
	return (1);
}

int	handle_unset_errors(char args[MAX_ARGS][BUFFER_SIZE], int *exit_code)
{
	int	idx;

	idx = 0;
	while (args[++idx][0] != '\0')
	{
		if (!is_valid_unset_identifier(args[idx]))
		{
			print_error_message_extra("unset: `", args[idx], 4, exit_code);
		}
		else if (ft_isdigit(args[idx][0]) == 1)
		{
			print_error_message_extra("unset: `", args[idx], 4, exit_code);
		}
	}
	return (1);
}
