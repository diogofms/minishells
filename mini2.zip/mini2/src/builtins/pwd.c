/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pwd.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: disilva <disilva@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/01 17:59:05 by disilva           #+#    #+#             */
/*   Updated: 2024/08/11 02:47:28 by disilva          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/minishell.h"

void	ft_pwd(char args[MAX_ARGS][BUFFER_SIZE], int *exit_code, int out_fd)
{
	char	*cwd;

	if (ft_strncmp(args[0], "pwd", ft_strlen(args[0])) == 0)
	{
		cwd = getcwd(NULL, 0);
		ft_putendl_fd(cwd, out_fd);
		free(cwd);
		*exit_code = 0;
	}
	else
		print_error_message_exit(args[0], 1, exit_code);
}
